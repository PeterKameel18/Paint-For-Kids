#pragma once
class Sound {
public:
	Sound();
	void play(int,bool);
};